'use strict';

/* ================= Icons ================= */
const ICONS = {
  home: '<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  dumbbell: '<path d="M6.5 6.5v11M17.5 6.5v11M3.5 9v6M20.5 9v6M6.5 12h11"/>',
  chart: '<path d="M3 3v18h18M7 15l4-4 3 3 5-6"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
  play: '<path d="M7 4.5l12 7.5-12 7.5z" fill="currentColor" stroke="none"/>',
  check: '<path d="M4.5 12.5l5 5L19.5 7"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16zM13 7l4 4"/>',
  up: '<path d="M6 15l6-6 6 6"/>',
  down: '<path d="M6 9l6 6 6-6"/>',
  left: '<path d="M15 6l-6 6 6 6"/>',
  qr: '<path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3z"/><path d="M14 14h3v3h-3zM20 14v3M14 20h3M20 20h1"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  video: '<path d="M3 6h13v12H3zM16 10l5-3v10l-5-3z"/>',
  swap: '<path d="M7 7h12l-3-3M17 17H5l3 3"/>',
  chev: '<path d="M9 6l6 6-6 6"/>'
};
const ico = (n, c) => '<svg class="i ' + (c || '') + '" viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[n] || '') + '</svg>';

const NAVS = [['home', 'Start', 'home'], ['lib', 'Übungen', 'dumbbell'], ['hist', 'Verlauf', 'chart']];
const navHtml = top => NAVS.map(n =>
  '<button class="' + (n[0] === top ? 'on' : '') + '" data-a="nav" data-to="' + n[0] + '">' + ico(n[2]) + '<span>' + n[1] + '</span></button>').join('');

const thumb = it => it && it.img && it.img.length ? imgTag(it.img[0], 'thimg') : '<span class="thph">' + ico('dumbbell') + '</span>';

/* ================= Start ================= */
function qrCard() {
  if (!QR) {
    return '<section class="qr-empty"><div class="qe-ico">' + ico('qr') + '</div><div class="grow"><h3>Gym-QR-Code</h3>' +
      '<p class="sub">Einmal scannen, danach liegt er hier immer bereit.</p></div><button class="btn sm" data-a="qrscan">Scannen</button></section>';
  }
  return '<section class="qr"><div class="qrbox" data-a="qrfull">' + qrSvg(QR) + '</div>' +
    '<div class="qr-foot"><span>Gym-Eintritt</span><button class="chip dark" data-a="qrfull">Vollbild, hell</button></div></section>';
}
function nextCard(r) {
  return '<section class="hero"><div class="sub">Nächste Einheit</div><h2>' + esc(r.name) + '</h2><p>' + esc(r.sub) + '</p>' +
    '<div class="sub">' + r.ex.length + ' Übungen, ca. ' + estMin(r) + ' Min.</div>' +
    '<button class="btn wide" data-a="start" data-id="' + r.id + '">' + ico('play') + ' Training starten</button></section>';
}
function splitRow(r, next) {
  const t = lastDoneTs(r.id);
  return '<div class="sp' + (next && next.id === r.id ? ' next' : '') + '"><button class="sp-main" data-a="start" data-id="' + r.id + '">' +
    '<b>' + esc(r.name) + '</b><span>' + esc(r.sub) + '</span><small>' + (t ? 'zuletzt ' + dateShort(t) : 'noch nicht gemacht') + '</small></button>' +
    '<button class="ibtn" data-a="edit" data-id="' + r.id + '" aria-label="' + esc(r.name) + ' bearbeiten">' + ico('edit') + '</button></div>';
}
function viewHome() {
  const next = nextRoutine(), cur = S.current;
  return '<header class="bar"><div class="grow"><div class="sub">' + esc(dateLong()) + '</div><h1>Training</h1></div>' +
    '<button class="ibtn" data-a="settings" aria-label="Einstellungen">' + ico('gear') + '</button></header>' +
    qrCard() +
    (cur ? '<section class="resume"><div><b>' + esc(cur.name) + ' läuft noch</b><div class="sub">' + doneCount(cur) + ' Sätze erledigt</div></div>' +
      '<button class="btn sm" data-a="resume">Fortsetzen</button></section>' : (next ? nextCard(next) : '')) +
    '<div class="sec"><h2>Dein Split</h2><button class="link" data-a="newplan">Neuer Plan</button></div>' +
    '<div class="split">' + (S.routines.length ? S.routines.map(r => splitRow(r, next)).join('') : '<p class="empty">Noch kein Plan. Lege oben einen neuen an oder füge den Standard-Plan in den Einstellungen hinzu.</p>') + '</div>' +
    '<p class="sub foot">' + (weekCount() === 1 ? '1 Training' : weekCount() + ' Trainings') + ' in den letzten 7 Tagen</p>';
}

/* ================= Training ================= */
function setRow(it, i, s, j, last) {
  const l = last && last[j];
  const phw = l && l.w != null ? fmt(l.w) : 'kg';
  const phr = l && l.r ? String(l.r) : s.pr;
  return '<div class="grid' + (s.done ? ' done' : '') + '"><span class="sn">' + (j + 1) + '</span>' +
    '<input class="in" inputmode="decimal" data-f="w" data-i="' + i + '" data-s="' + j + '" value="' + esc(s.w) + '" placeholder="' + esc(phw) + '" aria-label="Gewicht Satz ' + (j + 1) + '">' +
    '<input class="in" inputmode="numeric" data-f="r" data-i="' + i + '" data-s="' + j + '" value="' + esc(s.r) + '" placeholder="' + esc(phr) + '" aria-label="Wiederholungen Satz ' + (j + 1) + '">' +
    '<button class="tick' + (s.done ? ' on' : '') + '" data-a="tick" data-i="' + i + '" data-s="' + j + '" aria-label="Satz ' + (j + 1) + ' erledigt">' + ico('check') + '</button></div>';
}
function lastLine(last) {
  if (!last) return '';
  return '<div class="last"><em>Letztes Mal</em>' + last.map(l => l ? '<span>' + (l.w != null ? fmt(l.w) : '–') + ' × ' + esc(l.r || '–') + '</span>' : '').join('') + '</div>';
}
function itemCard(it, i) {
  const lib = getItem(it.dbId), last = lastFor(it.key);
  return '<section class="ex"><button class="ex-h" data-a="exinfo" data-ctx="workout" data-i="' + i + '"><span class="th">' + thumb(lib) + '</span>' +
    '<span class="ex-t"><b>' + esc(it.name) + '</b><small>' + esc(lib ? muscleTxt(lib.prim) : 'Tippen für Details') + '</small></span>' + ico('chev', 'mu') + '</button>' +
    (it.note ? '<p class="note">' + esc(it.note) + '</p>' : '') +
    '<div class="grid head"><span>Satz</span><span>kg</span><span>Wdh.</span><span></span></div>' +
    it.sets.map((s, j) => setRow(it, i, s, j, last)).join('') + lastLine(last) +
    '<div class="ex-f"><button class="link" data-a="addset" data-i="' + i + '">+ Satz</button><button class="link" data-a="delset" data-i="' + i + '">− Satz</button>' +
    '<span class="grow"></span><span class="sub">Pause ' + restTxt(it.rest) + '</span></div></section>';
}
function viewWorkout() {
  const c = S.current;
  if (!c) return '<p class="empty">Gerade läuft kein Training.</p><button class="btn wide" data-a="nav" data-to="home">Zur Startseite</button>';
  return '<header class="bar"><button class="ibtn" data-a="back" aria-label="Zurück zur Startseite">' + ico('left') + '</button>' +
    '<div class="grow"><h1>' + esc(c.name) + '</h1><div class="sub" id="wtime">' + clock((Date.now() - c.start) / 1000) + '</div></div>' +
    '<button class="btn sm" data-a="finish">Beenden</button></header>' +
    c.items.map((it, i) => itemCard(it, i)).join('') +
    '<button class="btn ghost wide" data-a="wadd">' + ico('plus') + ' Übung hinzufügen</button>';
}

/* ================= Plan bearbeiten ================= */
function planEx(r, e, i) {
  const lib = getItem(e.dbId);
  return '<section class="ex"><div class="ex-h2"><button class="ex-h" data-a="exinfo" data-ctx="plan" data-id="' + r.id + '" data-i="' + i + '"><span class="th">' + thumb(lib) + '</span>' +
    '<span class="ex-t"><b>' + esc(e.name) + '</b><small>' + esc(lib ? muscleTxt(lib.prim) : 'Kein Bild zugeordnet') + '</small></span></button>' +
    '<button class="ibtn" data-a="exup" data-id="' + r.id + '" data-i="' + i + '" aria-label="Nach oben">' + ico('up') + '</button>' +
    '<button class="ibtn" data-a="exdown" data-id="' + r.id + '" data-i="' + i + '" aria-label="Nach unten">' + ico('down') + '</button></div>' +
    '<div class="grid head"><span>Satz</span><span>kg</span><span>Wdh.</span><span></span></div>' +
    e.sets.map((s, j) => '<div class="grid"><span class="sn">' + (j + 1) + '</span>' +
      '<input class="in" inputmode="decimal" data-f="pw" data-id="' + r.id + '" data-i="' + i + '" data-s="' + j + '" value="' + esc(fmt(s.w)) + '" placeholder="kg" aria-label="Gewicht Satz ' + (j + 1) + '">' +
      '<input class="in" data-f="pr" data-id="' + r.id + '" data-i="' + i + '" data-s="' + j + '" value="' + esc(s.r) + '" placeholder="8-12" aria-label="Wiederholungen Satz ' + (j + 1) + '">' +
      '<button class="ibtn sm" data-a="delplset" data-id="' + r.id + '" data-i="' + i + '" data-s="' + j + '" aria-label="Satz ' + (j + 1) + ' löschen">' + ico('x') + '</button></div>').join('') +
    '<div class="ex-f"><button class="link" data-a="pladdset" data-id="' + r.id + '" data-i="' + i + '">+ Satz</button>' +
    '<button class="link" data-a="plsame" data-id="' + r.id + '" data-i="' + i + '">Alle wie Satz 1</button><span class="grow"></span>' +
    '<label class="rest">Pause <input class="in xs" inputmode="numeric" data-f="prest" data-id="' + r.id + '" data-i="' + i + '" value="' + (e.rest || 90) + '"> Sek.</label></div>' +
    '<label class="fld"><span>Notiz</span><input class="in" data-f="pnote" data-id="' + r.id + '" data-i="' + i + '" value="' + esc(e.note) + '" placeholder="z. B. Sitzhöhe, Griffweite"></label></section>';
}
function viewPlan(id) {
  const r = S.routines.find(x => x.id === id);
  if (!r) return viewHome();
  return '<header class="bar"><button class="ibtn" data-a="back" aria-label="Zurück">' + ico('left') + '</button><h1 class="grow">Plan bearbeiten</h1>' +
    '<button class="ibtn" data-a="mvup" data-id="' + r.id + '" aria-label="Plan nach oben">' + ico('up') + '</button>' +
    '<button class="ibtn" data-a="mvdown" data-id="' + r.id + '" aria-label="Plan nach unten">' + ico('down') + '</button></header>' +
    '<label class="fld"><span>Name</span><input class="in" data-f="rname" data-id="' + r.id + '" value="' + esc(r.name) + '"></label>' +
    '<label class="fld"><span>Beschreibung</span><input class="in" data-f="rsub" data-id="' + r.id + '" value="' + esc(r.sub) + '"></label>' +
    r.ex.map((e, i) => planEx(r, e, i)).join('') +
    '<button class="btn wide" data-a="pladd" data-id="' + r.id + '">' + ico('plus') + ' Übung hinzufügen</button>' +
    '<button class="btn ghost danger wide" data-a="plandel" data-id="' + r.id + '">Plan löschen</button>';
}

/* ================= Uebungen ================= */
function libFiltered() {
  const toks = LIBQ.q.toLowerCase().split(/\s+/).filter(Boolean);
  return libItems().filter(e => (!LIBQ.m || e.prim.indexOf(LIBQ.m) >= 0) && toks.every(t => e.s.indexOf(t) >= 0));
}
function libRow(e) {
  return '<button class="lrow" data-a="libopen" data-id="' + esc(e.id) + '"><span class="th">' + thumb(e) + '</span>' +
    '<span class="lrow-t"><b>' + esc(e.name) + '</b><small>' + esc(muscleTxt(e.prim)) + (EQUIP_DE[e.equip] ? ', ' + EQUIP_DE[e.equip] : '') + '</small></span>' + ico('chev', 'mu') + '</button>';
}
function libList() {
  const all = libFiltered(), shown = all.slice(0, LIBQ.n);
  if (!all.length) return '<p class="empty">Nichts gefunden. Probier einen anderen Suchbegriff oder leg eine eigene Übung an.</p>';
  return shown.map(libRow).join('') +
    (all.length > shown.length ? '<button class="btn ghost wide" data-a="libmore">Mehr anzeigen (' + (all.length - shown.length) + ' weitere)</button>' : '');
}
const chipM = (m, label) => '<button class="chip' + (LIBQ.m === m ? ' on' : '') + '" data-a="libm" data-m="' + esc(m) + '">' + esc(label) + '</button>';
function viewLib() {
  return '<header class="bar"><h1 class="grow">' + (PICK ? 'Übung wählen' : 'Übungen') + '</h1>' +
    (PICK ? '<button class="chip" data-a="pickcancel">Abbrechen</button>' : '') + '</header>' +
    '<input class="in search" data-f="lq" placeholder="Suchen, z. B. Brust, Latzug, Kurzhantel" value="' + esc(LIBQ.q) + '" aria-label="Suchen">' +
    '<div class="chips scroll">' + chipM('', 'Alle') + MUSCLE_ORDER.map(m => chipM(m, MUSCLE_DE[m])).join('') + '</div>' +
    '<div id="liblist" class="list">' + libList() + '</div>' +
    '<button class="btn ghost wide" data-a="newcustom">' + ico('plus') + ' Eigene Übung</button>' +
    (DB.ok ? '' : '<p class="sub foot">Die große Übungsdatenbank ist gerade nicht geladen, deshalb zeigt die App die kleine Notfall-Liste ohne Bilder. Mit Internet wird sie beim nächsten Start nachgeladen.</p>');
}

/* ================= Verlauf ================= */
function histRow(w) {
  const sets = w.items.reduce((a, it) => a + it.sets.filter(s => s.done).length, 0);
  const dur = w.end ? Math.round((w.end - w.start) / 60000) : 0;
  return '<button class="lrow" data-a="histopen" data-id="' + w.id + '"><span class="lrow-t"><b>' + esc(w.name) + '</b><small>' + dateShort(w.start) + ', ' + sets +
    ' Sätze, ' + dur + ' Min., ' + volume(w).toLocaleString('de-DE') + ' kg bewegt</small></span>' + ico('chev', 'mu') + '</button>';
}
function viewHist() {
  const ws = S.workouts;
  return '<header class="bar"><h1 class="grow">Verlauf</h1></header>' +
    (ws.length ? '<div class="stats"><div><b>' + weekCount() + '</b><span>in 7 Tagen</span></div><div><b>' + ws.length + '</b><span>gesamt</span></div></div>' +
      '<div class="list">' + ws.map(histRow).join('') + '</div>'
      : '<p class="empty">Noch kein Training gespeichert. Starte eine Einheit auf der Startseite.</p>');
}
function viewHistItem(id) {
  const w = S.workouts.find(x => x.id === id);
  if (!w) return viewHist();
  return '<header class="bar"><button class="ibtn" data-a="back" aria-label="Zurück">' + ico('left') + '</button><div class="grow"><h1>' + esc(w.name) + '</h1>' +
    '<div class="sub">' + esc(dateLong(w.start)) + '</div></div><button class="ibtn" data-a="histdel" data-id="' + w.id + '" aria-label="Training löschen">' + ico('trash') + '</button></header>' +
    w.items.filter(it => it.sets.some(s => s.done)).map(it => '<section class="ex"><h3>' + esc(it.name) + '</h3>' +
      it.sets.map((s, j) => s.done ? '<div class="hset"><span class="sn">' + (j + 1) + '</span><b>' + (s.w != null ? fmt(s.w) + ' kg' : '–') + '</b><span>× ' + esc(s.r || '–') + '</span></div>' : '').join('') + '</section>').join('');
}

/* ================= Einstellungen ================= */
function viewSettings() {
  return '<header class="bar"><button class="ibtn" data-a="back" aria-label="Zurück">' + ico('left') + '</button><h1 class="grow">Einstellungen</h1></header>' +
    '<section class="card"><h3>Gym-QR-Code</h3>' +
    (QR ? '<div class="qrmini">' + qrSvg(QR) + '</div><p class="sub break">' + esc(QR.length > 60 ? QR.slice(0, 57) + '…' : QR) + '</p>' : '<p class="sub">Noch kein Code gespeichert.</p>') +
    '<div class="btns"><button class="btn sm" data-a="qrscan">' + (QR ? 'Neu scannen' : 'Scannen') + '</button><button class="btn sm ghost" data-a="qrmanual">Text eingeben</button>' +
    (QR ? '<button class="btn sm ghost danger" data-a="qrdel">Löschen</button>' : '') + '</div>' +
    '<p class="sub">Tipp: Lange aufs App-Symbol drücken zeigt den Code sofort, und es gibt ein Widget für den Startbildschirm.</p></section>' +
    '<section class="card"><h3>Pause</h3><label class="rowl"><span>Standard für neue Übungen</span><span><input class="in xs" inputmode="numeric" data-f="defrest" value="' + (S.settings.rest || 90) + '"> Sek.</span></label></section>' +
    '<section class="card"><h3>Daten sichern</h3><p class="sub">Alles liegt nur auf diesem Handy. Mit einem Backup nimmst du Pläne und Verlauf zum nächsten Handy mit.</p>' +
    '<div class="btns"><button class="btn sm" data-a="export">Backup speichern</button><button class="btn sm ghost" data-a="import">Backup laden</button></div></section>' +
    '<section class="card"><h3>Plan</h3><p class="sub">Dein Push/Pull-Plan noch einmal als zusätzliche Pläne anlegen.</p><button class="btn sm ghost" data-a="addpreset">Standard-Plan hinzufügen</button></section>' +
    '<section class="card"><h3>Alles zurücksetzen</h3><p class="sub">Löscht Pläne, Verlauf und den gespeicherten QR-Code in dieser App.</p><button class="btn sm danger" data-a="reset">Zurücksetzen</button></section>' +
    '<p class="sub foot">Übungen: ' + DB.list.length + ' aus der freien Datenbank free-exercise-db (Public Domain).</p>';
}

/* ================= Overlays ================= */
function exSheet() {
  const o = OV; let it = null, title = '', note = '', ctx = '', yt = '';
  if (o.ctx === 'workout') {
    const x = S.current && S.current.items[o.i]; if (!x) return '';
    it = getItem(x.dbId); title = x.name; note = x.note; yt = x.name + ' Technik';
    ctx = '<button class="btn ghost wide" data-a="wreplace" data-i="' + o.i + '">' + ico('swap') + ' Übung ersetzen</button>' +
      (it ? '' : '<button class="btn ghost wide" data-a="wlink" data-i="' + o.i + '">Bild und Muskeln zuordnen</button>') +
      '<button class="btn ghost danger wide" data-a="wremove" data-i="' + o.i + '">Aus diesem Training entfernen</button>';
  } else if (o.ctx === 'plan') {
    const r = S.routines.find(q => q.id === o.id), x = r && r.ex[o.i]; if (!x) return '';
    it = getItem(x.dbId); title = x.name; note = x.note; yt = x.name + ' Technik';
    ctx = '<button class="btn ghost wide" data-a="plreplace" data-id="' + o.id + '" data-i="' + o.i + '">' + ico('swap') + ' Übung ersetzen</button>' +
      '<button class="btn ghost wide" data-a="pllink" data-id="' + o.id + '" data-i="' + o.i + '">Bild und Muskeln ändern</button>' +
      '<button class="btn ghost danger wide" data-a="plremove" data-id="' + o.id + '" data-i="' + o.i + '">Aus dem Plan entfernen</button>';
  } else {
    it = getItem(o.id); if (!it) return '';
    title = it.name; yt = it.name + (it.custom ? ' Technik' : ' exercise form');
    ctx = PICK ? '<button class="btn wide" data-a="pickchoose" data-id="' + esc(it.id) + '">Diese Übung wählen</button>'
      : '<button class="btn wide" data-a="libadd" data-id="' + esc(it.id) + '">' + ico('plus') + ' Zu einem Plan hinzufügen</button>' +
        (it.custom ? '<button class="btn ghost danger wide" data-a="customdel" data-id="' + esc(it.id) + '">Eigene Übung löschen</button>' : '');
  }
  const vbtn = cls => '<button class="btn wide' + cls + '" data-a="video" data-q="' + esc(yt) + '">' + ico('video') + ' Video suchen</button>';
  const imgs = it && it.img.length
    ? '<div class="anim' + (it.img.length > 1 ? ' two' : '') + '">' + it.img.slice(0, 2).map((u, k) => imgTag(u, 'a' + k)).join('') + '</div>' : '';
  const chips = it ? '<div class="mchips">' + it.prim.map(m => '<span class="mchip p">' + esc(MUSCLE_DE[m] || m) + '</span>').join('') +
    it.sec.map(m => '<span class="mchip">' + esc(MUSCLE_DE[m] || m) + '</span>').join('') + '</div>' : '';
  const meta = it ? [EQUIP_DE[it.equip], LEVEL_DE[it.level]].filter(Boolean).join(', ') : '';
  return '<div class="ov-bg" data-a="ovclose"></div><div class="sheet" role="dialog"><div class="sheet-h"><h2>' + esc(title) + '</h2>' +
    '<button class="ibtn" data-a="ovclose" aria-label="Schließen">' + ico('x') + '</button></div>' + imgs + chips +
    (meta ? '<p class="sub">' + esc(meta) + '</p>' : '') + (note ? '<p class="note">' + esc(note) + '</p>' : '') +
    (o.ctx === 'lib' ? ctx + vbtn(' ghost') : vbtn('') + ctx) +
    (it && it.instr.length ? '<h3>Ausführung (englisch)</h3><ol class="instr">' + it.instr.map(t => '<li>' + esc(t) + '</li>').join('') + '</ol>' : '') + '</div>';
}
function addToSheet() {
  const it = getItem(OV.id);
  if (!it) return '';
  return '<div class="ov-bg" data-a="ovclose"></div><div class="sheet" role="dialog"><div class="sheet-h"><h2>Zu welchem Plan?</h2><button class="ibtn" data-a="ovclose" aria-label="Schließen">' + ico('x') + '</button></div>' +
    '<p class="sub">' + esc(it.name) + ' wird mit 3 Sätzen am Ende des Plans eingefügt.</p>' +
    (S.routines.length ? '' : '<p class="empty">Lege zuerst auf der Startseite einen Plan an.</p>') +
    S.routines.map(r => '<button class="btn ghost wide" data-a="addto" data-id="' + r.id + '" data-x="' + esc(it.id) + '">' + esc(r.name) + '</button>').join('') + '</div>';
}
function newExSheet() {
  return '<div class="ov-bg" data-a="ovclose"></div><div class="sheet" role="dialog"><div class="sheet-h"><h2>Eigene Übung</h2><button class="ibtn" data-a="ovclose" aria-label="Schließen">' + ico('x') + '</button></div>' +
    '<label class="fld"><span>Name</span><input id="nxname" class="in" placeholder="z. B. Kabel-Pullover"></label>' +
    '<label class="fld"><span>Hauptmuskel</span><select id="nxm" class="in">' + MUSCLE_ORDER.map(m => '<option value="' + esc(m) + '">' + esc(MUSCLE_DE[m]) + '</option>').join('') + '</select></label>' +
    '<label class="fld"><span>Gerät</span><select id="nxe" class="in">' + Object.keys(EQUIP_DE).map(k => '<option value="' + esc(k) + '">' + esc(EQUIP_DE[k]) + '</option>').join('') + '</select></label>' +
    '<button class="btn wide" data-a="nxsave">Speichern</button></div>';
}
function qrFull() {
  return '<div class="qrfull" data-a="qrclose"><div class="qrfull-in">' + qrSvg(QR) + '</div><p>Tippen zum Schließen</p></div>';
}
function ovHtml() {
  if (!OV) return '';
  switch (OV.type) {
    case 'ex': return exSheet();
    case 'addto': return addToSheet();
    case 'newex': return newExSheet();
    case 'qr': return qrFull();
  }
  return '';
}
