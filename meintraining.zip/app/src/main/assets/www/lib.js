'use strict';

/* ================= Helfer ================= */
const $ = (s, r) => (r || document).querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);
const num = v => {
  if (v === null || v === undefined || v === '') return null;
  const n = parseFloat(String(v).replace(',', '.'));
  return isNaN(n) ? null : n;
};
const fmt = n => (n === null || n === undefined || n === '') ? '' : String(Math.round(n * 100) / 100).replace('.', ',');
const pad = n => (n < 10 ? '0' : '') + n;
const clock = sec => {
  sec = Math.max(0, Math.round(sec));
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return (h ? h + ':' + pad(m) : m) + ':' + pad(s);
};
const DAYS = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
const dateShort = ts => { const d = new Date(ts); return DAYS[d.getDay()] + ', ' + pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.'; };
const dateLong = ts => new Date(ts || Date.now()).toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
const bridge = (fn, ...a) => {
  try { const A = window.Android; return A && typeof A[fn] === 'function' ? A[fn](...a) : undefined; } catch (e) { return undefined; }
};

/* ================= Zustand ================= */
const KEY = 'mt.state.v1';
const DBKEY = 'mt.db.v1';
let S = null;                      // gesamter App-Zustand
let QR = '';                       // gespeicherter QR-Inhalt
let PICK = null;                   // Auswahl-Modus der Uebungsbibliothek
let OV = null;                     // offenes Overlay (Detailfenster, QR Vollbild ...)
let DLG = null;                    // offener Dialog
let LIBQ = { q: '', m: '', n: 60 };// Bibliothek: Suche, Muskel, Anzahl
let LASTH = '';

function cloneRoutine(p) {
  return {
    id: uid(), name: p.name, sub: p.sub || '',
    ex: p.ex.map(e => ({
      id: uid(), key: e.k, name: e.n, dbId: null, q: e.q || [], rest: e.rest, note: e.note || '',
      sets: Array.from({ length: e.s }, () => ({ w: e.w == null ? null : e.w, r: e.r }))
    }))
  };
}
function freshState() {
  return { v: 1, routines: PRESET.map(cloneRoutine), workouts: [], current: null, custom: [], settings: { rest: 90, qrHome: false } };
}
function loadState() {
  try {
    const j = localStorage.getItem(KEY);
    if (j) { const s = JSON.parse(j); if (s && Array.isArray(s.routines)) return s; }
  } catch (e) { }
  return null;
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { } }

/* ================= Uebungsdatenbank ================= */
let DB = { list: [], by: {}, ok: false };

function stem(t) {
  if (t.endsWith('sses')) return t.slice(0, -2);
  if (t.endsWith('flyes')) return t.slice(0, -3) + 'y';
  if (t.endsWith('ies') && t.length > 4) return t.slice(0, -3) + 'y';
  if (t.length > 3 && t.endsWith('s') && !t.endsWith('ss')) return t.slice(0, -1);
  return t;
}
function tokenize(s) {
  return String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ').trim().split(' ').filter(Boolean).map(stem);
}
const tokenSet = s => new Set(tokenize(s));
const muscleTxt = list => list.map(m => MUSCLE_DE[m] || m).join(', ');

function normEntry(e) {
  const imgs = Array.isArray(e.images) ? e.images : [];
  const o = {
    id: String(e.id || e.name), name: e.name,
    prim: e.primaryMuscles || e.prim || [], sec: e.secondaryMuscles || e.sec || [],
    equip: e.equipment || e.equip || 'other', level: e.level || '', cat: e.category || '',
    instr: e.instructions || e.instr || [],
    img: imgs.map(p => /^https?:/.test(p) ? p : IMG_BASE + encodeURI(p))
  };
  o.t = tokenSet(o.name + ' ' + (e.alias || ''));
  o.s = (o.name + ' ' + (e.alias || '') + ' ' + muscleTxt(o.prim.concat(o.sec)) + ' ' + (EQUIP_DE[o.equip] || o.equip)).toLowerCase();
  return o;
}

async function loadDB() {
  let arr = null;
  try { const r = await fetch('data/exercises.json'); if (r.ok) arr = await r.json(); } catch (e) { }
  if (!Array.isArray(arr) || arr.length < 100) {
    arr = null;
    try { const j = localStorage.getItem(DBKEY); if (j) arr = JSON.parse(j); } catch (e) { }
  }
  if (!Array.isArray(arr) || arr.length < 100) {
    arr = null;
    try {
      const r = await fetch(REMOTE_DB);
      if (r.ok) { arr = await r.json(); try { localStorage.setItem(DBKEY, JSON.stringify(arr)); } catch (e) { } }
    } catch (e) { }
  }
  if (Array.isArray(arr) && arr.length >= 100) { DB.list = arr.map(normEntry); DB.ok = true; }
  else { DB.list = FALLBACK.map(normEntry); DB.ok = false; }
  DB.by = {};
  DB.list.forEach(e => { DB.by[e.id] = e; });
}

/* Beste Uebung zu einer Liste englischer Suchbegriffe finden (frueher genannte zaehlen mehr). */
function findEx(queries) {
  let best = null, bs = -1;
  queries.forEach((q, qi) => {
    const qt = tokenize(q);
    if (!qt.length) return;
    const qn = qt.join(' ');
    for (const e of DB.list) {
      let hit = 0;
      for (const t of qt) if (e.t.has(t)) hit++;
      let score;
      if (hit === qt.length) {
        score = 1000 - qi * 60 - (e.t.size - qt.length) * 12 + (tokenize(e.name).join(' ') === qn ? 300 : 0);
      } else if (qt.length >= 3 && hit >= qt.length - 1) {
        score = 300 - qi * 60 - (e.t.size - hit) * 12;
      } else continue;
      if (e.img.length) score += 8;
      if (score > bs) { bs = score; best = e; }
    }
  });
  return best;
}

function customItem(c) {
  return {
    id: c.id, name: c.name, prim: c.prim || [], sec: [], equip: c.equip || 'other', level: '', cat: '', instr: [], img: [],
    custom: true, t: tokenSet(c.name),
    s: (c.name + ' ' + muscleTxt(c.prim || []) + ' ' + (EQUIP_DE[c.equip] || '')).toLowerCase()
  };
}
const libItems = () => S.custom.map(customItem).concat(DB.list);
function getItem(id) {
  if (!id) return null;
  const c = S.custom.find(x => x.id === id);
  return c ? customItem(c) : (DB.by[id] || null);
}

/* Plan-Uebungen automatisch mit Bild und Muskelgruppen verknuepfen (Handarbeit hat Vorrang). */
function autoLink() {
  let ch = false;
  S.routines.forEach(r => r.ex.forEach(e => {
    if (e.manual || !e.q || !e.q.length) return;
    if (e.dbId && getItem(e.dbId)) return;
    const m = findEx(e.q);
    if (m) { e.dbId = m.id; ch = true; }
  }));
  if (ch) save();
}

/* ================= Training: Hilfsfunktionen ================= */
function nextRoutine() {
  if (!S.routines.length) return null;
  const last = S.workouts[0];
  if (!last) return S.routines[0];
  const i = S.routines.findIndex(r => r.id === last.rid);
  return S.routines[(i + 1) % S.routines.length] || S.routines[0];
}
function lastFor(key) {
  for (const w of S.workouts) {
    const it = w.items.find(x => x.key === key && x.sets.some(s => s.done));
    if (it) return it.sets.map(s => s.done ? { w: s.w, r: s.r } : null);
  }
  return null;
}
const doneCount = c => c.items.reduce((a, it) => a + it.sets.filter(s => s.done).length, 0);
function volume(w) {
  let v = 0;
  w.items.forEach(it => it.sets.forEach(s => { if (s.done) v += (num(s.w) || 0) * (parseInt(s.r, 10) || 0); }));
  return Math.round(v);
}
function lastDoneTs(rid) { const w = S.workouts.find(x => x.rid === rid); return w ? w.start : 0; }
function estMin(r) {
  const sec = r.ex.reduce((a, e) => a + e.sets.length * ((e.rest || 90) + 45), 0);
  return Math.max(5, Math.round(sec / 300) * 5);
}
function weekCount() {
  const since = Date.now() - 7 * 864e5;
  return S.workouts.filter(w => w.start >= since).length;
}
function restTxt(s) { s = s || 90; return s % 60 === 0 ? (s / 60) + ' Min.' : (s >= 60 ? Math.floor(s / 60) + ':' + pad(s % 60) + ' Min.' : s + ' Sek.'); }

/* ================= QR-Code ================= */
const qrCache = {};
function qrSvg(text) {
  let m = qrCache[text];
  if (m === undefined) { m = bridge('qrMatrix', text) || ''; qrCache[text] = m; }
  if (!m) return '<div class="sub">QR-Code konnte nicht dargestellt werden.</div>';
  const i = m.indexOf(':'), n = +m.slice(0, i), bits = m.slice(i + 1);
  let d = '';
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (bits.charCodeAt(y * n + x) === 49) d += 'M' + x + ' ' + y + 'h1v1h-1z';
  const q = 4, t = n + 2 * q;
  return '<svg viewBox="' + (-q) + ' ' + (-q) + ' ' + t + ' ' + t + '" shape-rendering="crispEdges" role="img" aria-label="QR-Code">' +
    '<rect x="' + (-q) + '" y="' + (-q) + '" width="' + t + '" height="' + t + '" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
}

/* ================= Pausen-Timer ================= */
let REST = { end: 0, total: 0, fin: false };
let AC = null;
function beep() {
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    if (AC.state === 'suspended') AC.resume();
    const o = AC.createOscillator(), g = AC.createGain();
    o.frequency.value = 880; g.gain.value = 0.15;
    o.connect(g); g.connect(AC.destination);
    o.start(); o.stop(AC.currentTime + 0.35);
  } catch (e) { }
}
function startRest(sec) {
  REST = { end: Date.now() + sec * 1000, total: sec, fin: false };
  drawRest();
}
function drawRest() {
  const el = $('#restbar');
  if (!el) return;
  el.classList.remove('done');
  if (!REST.end) { el.hidden = true; el.innerHTML = ''; return; }
  el.hidden = false;
  el.innerHTML = '<div class="rt"><span>Pause</span><b id="rtime">0:00</b></div>' +
    '<div class="rb"><button class="chip" data-a="rminus">−15</button><button class="chip" data-a="rplus">+15</button><button class="chip" data-a="rskip">Weiter</button></div>' +
    '<div class="rp"><i id="rprog"></i></div>';
  tickRest();
}
function tickRest() {
  if (!REST.end) return;
  const el = $('#restbar'), t = $('#rtime'), p = $('#rprog');
  const left = Math.ceil((REST.end - Date.now()) / 1000);
  if (left <= 0) {
    if (!REST.fin) {
      REST.fin = true; bridge('vibrate', 400); beep();
      if (t) t.textContent = 'Los!';
      if (p) p.style.width = '0%';
      if (el) el.classList.add('done');
      setTimeout(() => { if (REST.fin && REST.end) { REST.end = 0; drawRest(); } }, 4000);
    }
    return;
  }
  if (t) t.textContent = clock(left);
  if (p) p.style.width = Math.max(0, Math.min(100, 100 * left / REST.total)) + '%';
}

/* ================= Dialog, Toast, Fehleranzeige ================= */
function dlg(o) { return new Promise(res => { DLG = { o, res }; drawDlg(); }); }
function drawDlg() {
  const el = $('#dlg');
  if (!el) return;
  if (!DLG) { el.innerHTML = ''; el.className = ''; return; }
  const o = DLG.o;
  el.className = 'on';
  el.innerHTML = '<div class="dlg-bg" data-a="dlgno"></div><div class="dlgbox" role="dialog"><h3>' + esc(o.title) + '</h3>' +
    (o.text ? '<p class="sub">' + esc(o.text) + '</p>' : '') +
    (o.input != null ? '<input id="dlgin" class="in wide" value="' + esc(o.input) + '" placeholder="' + esc(o.ph || '') + '"' + (o.im ? ' inputmode="' + o.im + '"' : '') + '>' : '') +
    (o.check ? '<label class="chk"><input type="checkbox" id="dlgchk"><span>' + esc(o.check) + '</span></label>' : '') +
    '<div class="btns"><button class="btn ghost" data-a="dlgno">Abbrechen</button><button class="btn' + (o.danger ? ' danger' : '') + '" data-a="dlgok">' + esc(o.ok || 'OK') + '</button></div></div>';
  const inp = $('#dlgin');
  if (inp) setTimeout(() => { try { inp.focus(); inp.select(); } catch (e) { } }, 50);
}
function closeDlg(ok) {
  const d = DLG; if (!d) return;
  const chk = $('#dlgchk'), inp = $('#dlgin');
  const res = ok ? { checked: !!(chk && chk.checked), value: inp ? inp.value : '' } : null;
  DLG = null; drawDlg();
  d.res(res);
}
let TT = null;
function toast(msg) {
  const el = $('#toast');
  if (!el) return;
  el.textContent = msg; el.hidden = false;
  clearTimeout(TT); TT = setTimeout(() => { el.hidden = true; }, 2400);
}
function showErr(msg) {
  const el = $('#err');
  if (!el) return;
  el.hidden = false;
  el.innerHTML = '<b>Da ist etwas schiefgelaufen</b><div>' + esc(msg) + '</div><button class="btn sm" onclick="this.parentNode.hidden=true">Schließen</button>';
}
window.addEventListener('error', e => showErr((e.message || 'Fehler') + (e.lineno ? ' (Zeile ' + e.lineno + ')' : '')));
window.addEventListener('unhandledrejection', e => showErr(String((e.reason && e.reason.message) || e.reason)));

/* ================= Bilder ================= */
function imgFb(el) {
  if (el.dataset.fb) { el.style.visibility = 'hidden'; return; }
  el.dataset.fb = '1';
  el.src = el.src.replace(IMG_BASE, IMG_ALT);
}
const imgTag = (u, cls) => '<img class="' + (cls || '') + '" src="' + esc(u) + '" alt="" loading="lazy" onerror="imgFb(this)">';

/* Bilder der Plan-Uebungen einmal vorladen, damit sie spaeter auch mit schlechtem Empfang da sind. */
function prefetchPlan() {
  const urls = [];
  S.routines.forEach(r => r.ex.forEach(e => { const it = getItem(e.dbId); if (it) it.img.slice(0, 2).forEach(u => urls.push(u)); }));
  const q = Array.from(new Set(urls));
  let i = 0;
  const next = () => {
    if (i >= q.length) return;
    const im = new Image();
    im.onload = im.onerror = () => setTimeout(next, 40);
    im.src = q[i++];
  };
  for (let k = 0; k < 3; k++) next();
}
