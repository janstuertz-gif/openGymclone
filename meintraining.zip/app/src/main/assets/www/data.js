'use strict';

/* ---------- Quellen fuer Uebungsdaten (Public Domain: yuhonas/free-exercise-db) ---------- */
const REMOTE_DB = 'https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/dist/exercises.json';
const IMG_BASE = 'https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/exercises/';
const IMG_ALT = 'https://cdn.jsdelivr.net/gh/yuhonas/free-exercise-db@main/exercises/';

/* ---------- Uebersetzungen ---------- */
const MUSCLE_DE = {
  'chest': 'Brust', 'lats': 'Latissimus', 'middle back': 'Mittlerer Rücken', 'lower back': 'Unterer Rücken',
  'traps': 'Trapez', 'shoulders': 'Schultern', 'biceps': 'Bizeps', 'triceps': 'Trizeps', 'forearms': 'Unterarme',
  'abdominals': 'Bauch', 'quadriceps': 'Quadrizeps', 'hamstrings': 'Beinbeuger', 'glutes': 'Gesäß',
  'calves': 'Waden', 'adductors': 'Adduktoren', 'abductors': 'Abduktoren', 'neck': 'Nacken'
};
const MUSCLE_ORDER = ['chest', 'lats', 'middle back', 'lower back', 'traps', 'shoulders', 'biceps', 'triceps',
  'forearms', 'abdominals', 'quadriceps', 'hamstrings', 'glutes', 'calves', 'adductors', 'abductors', 'neck'];
const EQUIP_DE = {
  'machine': 'Maschine', 'cable': 'Kabelzug', 'dumbbell': 'Kurzhantel', 'barbell': 'Langhantel',
  'e-z curl bar': 'SZ-Stange', 'body only': 'Körpergewicht', 'bands': 'Bänder', 'kettlebells': 'Kettlebell',
  'medicine ball': 'Medizinball', 'exercise ball': 'Gymnastikball', 'foam roll': 'Faszienrolle', 'other': 'Sonstiges'
};
const LEVEL_DE = { 'beginner': 'Anfänger', 'intermediate': 'Fortgeschritten', 'expert': 'Profi' };
const WEEKDAY_LONG = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
const WEEK_ORDER = [1, 2, 3, 4, 5, 6, 0];   // Montag bis Sonntag (Zahlen wie Date.getDay)

/* ---------- Dein Plan (Push / Pull, A/B-Rotation) ---------- */
/* k = fester Name der Uebung (Werte vom letzten Mal gelten fuer alle Plaene), n = Anzeigename,
   s = Saetze, r = Wiederholungen, rest = Pause in Sekunden, w = Startgewicht (nur Einzel-Richtwerte),
   q = Suchbegriffe (englisch) fuer Bild und Muskelgruppen in der Uebungsdatenbank */
const PRESET = [
  {
    name: 'Push A', day: 2, sub: 'Brust, seitliche Schulter, Trizeps, Quads, Bauch', ex: [
      { k: 'brustpresse', n: 'Brustpresse (Maschine)', s: 3, r: '8-12', rest: 120, note: 'Schwere Hauptübung für die gesamte Brust. Richtwert: 29–36 kg.', q: ['machine bench press', 'leverage chest press', 'chest press machine', 'chest press'] },
      { k: 'schraegpresse', n: 'Schrägpresse (oder Multipresse)', s: 3, r: '8-12', rest: 120, note: 'Obere Brust; bei der Multipresse Bank auf ca. 30°. Richtwert: 23–29 kg.', q: ['leverage incline chest press', 'incline chest press', 'smith machine incline bench press', 'incline dumbbell press'] },
      { k: 'seitheben', n: 'Seitheben (Kurzhanteln)', s: 3, r: '12-15', rest: 90, w: 6, note: 'Kontrolliert, ohne Schwung. Richtwert: 6 kg.', q: ['side lateral raise', 'dumbbell lateral raise', 'lateral raise'] },
      { k: 'trizepsdruecken', n: 'Trizepsdrücken (Kabel)', s: 3, r: '10-15', rest: 90, w: 11.3, note: 'Mit Seil oder Stange am Kabelturm. Richtwert: 11,3 kg.', q: ['triceps pushdown', 'triceps pushdown rope attachment', 'cable pushdown'] },
      { k: 'beinpresse', n: 'Beinpresse (Maschine)', s: 3, r: '8-12', rest: 120, note: 'Voller Bewegungsradius für Oberschenkelvorderseite und Gesäß.', q: ['leg press'] },
      { k: 'kneeraises', n: 'Hängende Knee Raises / Leg Raises', s: 3, r: '10-15', rest: 60, note: 'Becken am Ende leicht einrollen, langsam und ohne Schwung.', q: ['hanging leg raise', 'knee hip raise on parallel bars', 'hanging knee raise'] }
    ]
  },
  {
    name: 'Pull A', day: 3, sub: 'Rückenbreite, hintere Schulter, Bizeps, Beinrückseite, unterer Rücken', ex: [
      { k: 'latzug', n: 'Latzug (Cable Bar Lateral Pulldown)', s: 3, r: '8-12', rest: 120, note: 'Zur oberen Brust ziehen, Fokus auf Rückenbreite. Richtwert: 23–29 kg.', q: ['wide grip lat pulldown', 'lat pulldown', 'cable bar lateral pulldown'] },
      { k: 'rudern_sitzend', n: 'Rudern sitzend (Kabelzug / Maschine)', s: 3, r: '8-12', rest: 120, w: 18, note: 'Schulterblätter bewusst hinten zusammenziehen. Bisher 18 kg bei 15 Wdh.', q: ['seated cable rows', 'seated cable row'] },
      { k: 'reversefly', n: 'Reverse Fly (Maschine, paralleler Griff)', s: 3, r: '12-15', rest: 90, note: 'Hintere Schulter und gesunde Schulterhaltung.', q: ['reverse machine flyes', 'reverse flyes', 'rear delt machine fly'] },
      { k: 'bizepsmaschine', n: 'Bizeps-Maschine', s: 3, r: '8-12', rest: 90, note: 'Voller Bewegungsradius, kein Schwung aus dem Oberkörper.', q: ['machine bicep curl', 'preacher curl', 'machine preacher curl'] },
      { k: 'beinbeuger_sitzend', n: 'Beinbeuger (Maschine, sitzend)', s: 3, r: '10-15', rest: 90, note: 'Kontrollierte Rückführung, isoliert die Oberschenkelrückseite.', q: ['seated leg curl'] },
      { k: 'rueckenstrecker', n: 'Rückenstrecker (Hyperextension)', s: 2, r: '12-15', rest: 60, note: 'Kontrolliert bis in die Waagerechte, nicht überstrecken.', q: ['hyperextensions back extensions', 'hyperextensions', 'back extension'] }
    ]
  },
  {
    name: 'Push B', day: 5, sub: 'Schulter, Brust-Dehnung, seitliche Schulter, Quads, Trizeps', ex: [
      { k: 'schulterpresse', n: 'Schulterpresse (Lever Shoulder Press)', s: 3, r: '8-12', rest: 120, w: 9, note: 'Als erste Übung mit voller Energie. Richtwert: 9 kg.', q: ['machine shoulder military press', 'lever shoulder press', 'shoulder press machine', 'machine shoulder press'] },
      { k: 'brustpresse', n: 'Brustpresse (Maschine)', s: 3, r: '8-12', rest: 120, note: 'Zweiter Brust-Reiz der Woche. Richtwert: 29–36 kg.', q: ['machine bench press', 'leverage chest press', 'chest press machine', 'chest press'] },
      { k: 'butterfly', n: 'Butterfly (Lever Seated Fly)', s: 3, r: '10-15', rest: 90, note: 'Kontrollierte Dehnung, Brust aktiv zusammendrücken. Richtwert: 29–36 kg.', q: ['butterfly', 'pec deck', 'seated fly', 'machine fly'] },
      { k: 'seitheben', n: 'Seitheben (Kurzhanteln oder Kabelzug)', s: 3, r: '12-15', rest: 90, w: 6, note: 'Zweiter Reiz für die seitliche Schulter. Richtwert: 6 kg.', q: ['side lateral raise', 'dumbbell lateral raise', 'lateral raise'] },
      { k: 'beinstrecker', n: 'Beinstrecker (Maschine)', s: 3, r: '12-15', rest: 90, note: 'Oben kurz halten, Quads gezielt ausbelasten.', q: ['leg extensions', 'leg extension'] },
      { k: 'ueberkopf_trizeps', n: 'Überkopf-Trizepsstrecken (Kabel)', s: 3, r: '10-15', rest: 90, note: 'Trainiert den langen Trizepskopf besonders gut.', q: ['cable rope overhead triceps extension', 'overhead triceps extension', 'triceps overhead extension'] },
      { k: 'kneeraises', n: 'Hängende Knee Raises / Leg Raises (Finisher)', s: 2, r: '10-15', rest: 60, note: 'Finisher am Ende der Einheit.', q: ['hanging leg raise', 'knee hip raise on parallel bars', 'hanging knee raise'] }
    ]
  },
  {
    name: 'Pull B', day: 0, sub: 'Rückentiefe, hintere Schulter, Bizeps, Beinrückseite, Waden', ex: [
      { k: 'rudern_eng', n: 'Rudern (enger Griff oder einarmig)', s: 3, r: '8-12', rest: 120, note: 'Anderer Winkel als Pull A, Fokus auf Rückentiefe.', q: ['close grip seated cable row', 'seated cable rows', 'one arm dumbbell row'] },
      { k: 'latzug_unter', n: 'Latzug (Untergriff oder enger Griff)', s: 3, r: '8-12', rest: 120, note: 'Zweiter Rücken-Reiz mit anderem Griff als Pull A.', q: ['underhand cable pulldowns', 'reverse grip lat pulldown', 'close grip front lat pulldown'] },
      { k: 'facepull', n: 'Face Pulls (Kabel)', s: 3, r: '12-15', rest: 90, note: 'Zur Stirn ziehen, Ellbogen hoch; hintere Schulter und Haltung.', q: ['face pull'] },
      { k: 'langhantelcurl', n: 'Langhantel- oder SZ-Curls', s: 3, r: '10-12', rest: 90, note: 'Ellbogen seitlich am Körper, kein Schwung aus dem Rücken, unten ganz strecken.', q: ['barbell curl', 'ez bar curl'] },
      { k: 'beinbeuger_liegend', n: 'Beinbeuger (Maschine, liegend)', s: 3, r: '10-15', rest: 90, note: 'Anderer Winkel als Pull A (liegend statt sitzend).', q: ['lying leg curls', 'lying leg curl'] },
      { k: 'wadenheben_presse', n: 'Wadenheben an der Beinpresse', s: 3, r: '12-15', rest: 60, note: 'Fußballen auf die Platte, unten 1 Sek. dehnen.', q: ['calf press on the leg press machine', 'calf press'] }
    ]
  }
];

/* ---------- Notfall-Liste, falls die Uebungsdatenbank nicht geladen werden konnte ---------- */
const FALLBACK = [
  { id: 'fb_brustpresse', name: 'Brustpresse (Maschine)', prim: ['chest'], sec: ['triceps', 'shoulders'], equip: 'machine', alias: 'machine bench press leverage chest press chest press machine' },
  { id: 'fb_schraegpresse', name: 'Schrägpresse (Maschine)', prim: ['chest'], sec: ['shoulders', 'triceps'], equip: 'machine', alias: 'leverage incline chest press incline chest press smith machine incline bench press incline dumbbell press' },
  { id: 'fb_butterfly', name: 'Butterfly (Maschine)', prim: ['chest'], sec: ['shoulders'], equip: 'machine', alias: 'butterfly pec deck seated fly machine fly' },
  { id: 'fb_bankdruecken', name: 'Bankdrücken (Langhantel)', prim: ['chest'], sec: ['triceps', 'shoulders'], equip: 'barbell', alias: 'barbell bench press' },
  { id: 'fb_schraegbank_kh', name: 'Schrägbankdrücken (Kurzhanteln)', prim: ['chest'], sec: ['shoulders', 'triceps'], equip: 'dumbbell', alias: 'incline dumbbell press' },
  { id: 'fb_fliegende', name: 'Fliegende (Kurzhanteln)', prim: ['chest'], sec: ['shoulders'], equip: 'dumbbell', alias: 'dumbbell flyes' },
  { id: 'fb_liegestuetze', name: 'Liegestütze', prim: ['chest'], sec: ['triceps', 'shoulders'], equip: 'body only', alias: 'pushups push up' },
  { id: 'fb_latzug', name: 'Latzug', prim: ['lats'], sec: ['biceps', 'middle back'], equip: 'cable', alias: 'wide grip lat pulldown lat pulldown cable bar lateral pulldown' },
  { id: 'fb_latzug_unter', name: 'Latzug Untergriff', prim: ['lats'], sec: ['biceps'], equip: 'cable', alias: 'underhand cable pulldowns reverse grip lat pulldown close grip front lat pulldown' },
  { id: 'fb_rudern_sitzend', name: 'Rudern sitzend (Kabel)', prim: ['middle back'], sec: ['lats', 'biceps'], equip: 'cable', alias: 'seated cable rows seated cable row' },
  { id: 'fb_rudern_eng', name: 'Rudern enger Griff (Kabel)', prim: ['middle back'], sec: ['lats', 'biceps'], equip: 'cable', alias: 'close grip seated cable row' },
  { id: 'fb_rudern_lh', name: 'Rudern vorgebeugt (Langhantel)', prim: ['middle back'], sec: ['lats', 'biceps'], equip: 'barbell', alias: 'bent over barbell row' },
  { id: 'fb_rudern_kh', name: 'Einarmiges Rudern (Kurzhantel)', prim: ['lats'], sec: ['biceps', 'middle back'], equip: 'dumbbell', alias: 'one arm dumbbell row' },
  { id: 'fb_klimmzuege', name: 'Klimmzüge', prim: ['lats'], sec: ['biceps', 'middle back'], equip: 'body only', alias: 'pullups pull up chin up' },
  { id: 'fb_rueckenstrecker', name: 'Rückenstrecker', prim: ['lower back'], sec: ['glutes', 'hamstrings'], equip: 'body only', alias: 'hyperextensions back extensions hyperextension back extension' },
  { id: 'fb_kreuzheben', name: 'Kreuzheben', prim: ['lower back'], sec: ['glutes', 'hamstrings', 'traps'], equip: 'barbell', alias: 'deadlift barbell deadlift' },
  { id: 'fb_schulterpresse', name: 'Schulterpresse (Maschine)', prim: ['shoulders'], sec: ['triceps'], equip: 'machine', alias: 'machine shoulder military press lever shoulder press shoulder press machine' },
  { id: 'fb_schulterdruecken_kh', name: 'Schulterdrücken (Kurzhanteln)', prim: ['shoulders'], sec: ['triceps'], equip: 'dumbbell', alias: 'dumbbell shoulder press' },
  { id: 'fb_seitheben', name: 'Seitheben (Kurzhanteln)', prim: ['shoulders'], sec: [], equip: 'dumbbell', alias: 'side lateral raise dumbbell lateral raise lateral raise' },
  { id: 'fb_reversefly', name: 'Reverse Fly (Maschine)', prim: ['shoulders'], sec: ['middle back', 'traps'], equip: 'machine', alias: 'reverse machine flyes reverse flyes rear delt machine fly' },
  { id: 'fb_facepull', name: 'Face Pulls (Kabel)', prim: ['shoulders'], sec: ['traps', 'middle back'], equip: 'cable', alias: 'face pull' },
  { id: 'fb_frontheben', name: 'Frontheben', prim: ['shoulders'], sec: [], equip: 'dumbbell', alias: 'front dumbbell raise' },
  { id: 'fb_shrugs', name: 'Schulterheben (Shrugs)', prim: ['traps'], sec: [], equip: 'dumbbell', alias: 'dumbbell shrug' },
  { id: 'fb_bizepsmaschine', name: 'Bizeps-Maschine', prim: ['biceps'], sec: ['forearms'], equip: 'machine', alias: 'machine bicep curl preacher curl machine preacher curl' },
  { id: 'fb_langhantelcurl', name: 'Langhantel-Curls', prim: ['biceps'], sec: ['forearms'], equip: 'barbell', alias: 'barbell curl' },
  { id: 'fb_sz_curl', name: 'SZ-Curls', prim: ['biceps'], sec: ['forearms'], equip: 'e-z curl bar', alias: 'ez bar curl' },
  { id: 'fb_hammercurl', name: 'Hammer-Curls', prim: ['biceps'], sec: ['forearms'], equip: 'dumbbell', alias: 'hammer curls' },
  { id: 'fb_trizepsdruecken', name: 'Trizepsdrücken (Kabel)', prim: ['triceps'], sec: [], equip: 'cable', alias: 'triceps pushdown triceps pushdown rope attachment cable pushdown' },
  { id: 'fb_ueberkopf_trizeps', name: 'Überkopf-Trizepsstrecken (Kabel)', prim: ['triceps'], sec: [], equip: 'cable', alias: 'cable rope overhead triceps extension overhead triceps extension' },
  { id: 'fb_dips', name: 'Dips', prim: ['triceps'], sec: ['chest', 'shoulders'], equip: 'body only', alias: 'dips triceps version' },
  { id: 'fb_stirndruecken', name: 'Stirndrücken (SZ-Stange)', prim: ['triceps'], sec: [], equip: 'e-z curl bar', alias: 'ez bar skullcrusher lying triceps extension' },
  { id: 'fb_handgelenk', name: 'Handgelenkcurls', prim: ['forearms'], sec: [], equip: 'barbell', alias: 'wrist curls' },
  { id: 'fb_beinpresse', name: 'Beinpresse', prim: ['quadriceps'], sec: ['glutes', 'hamstrings'], equip: 'machine', alias: 'leg press' },
  { id: 'fb_beinstrecker', name: 'Beinstrecker', prim: ['quadriceps'], sec: [], equip: 'machine', alias: 'leg extensions leg extension' },
  { id: 'fb_beinbeuger_sitz', name: 'Beinbeuger sitzend', prim: ['hamstrings'], sec: ['calves'], equip: 'machine', alias: 'seated leg curl' },
  { id: 'fb_beinbeuger_liegend', name: 'Beinbeuger liegend', prim: ['hamstrings'], sec: ['calves'], equip: 'machine', alias: 'lying leg curls lying leg curl' },
  { id: 'fb_kniebeuge', name: 'Kniebeuge', prim: ['quadriceps'], sec: ['glutes', 'hamstrings'], equip: 'barbell', alias: 'barbell squat squat' },
  { id: 'fb_rdl', name: 'Rumänisches Kreuzheben', prim: ['hamstrings'], sec: ['glutes', 'lower back'], equip: 'barbell', alias: 'romanian deadlift' },
  { id: 'fb_ausfallschritte', name: 'Ausfallschritte', prim: ['quadriceps'], sec: ['glutes', 'hamstrings'], equip: 'dumbbell', alias: 'dumbbell lunges' },
  { id: 'fb_hipthrust', name: 'Hip Thrust', prim: ['glutes'], sec: ['hamstrings'], equip: 'barbell', alias: 'barbell hip thrust' },
  { id: 'fb_abduktoren', name: 'Abduktoren-Maschine', prim: ['abductors'], sec: ['glutes'], equip: 'machine', alias: 'thigh abductor' },
  { id: 'fb_adduktoren', name: 'Adduktoren-Maschine', prim: ['adductors'], sec: [], equip: 'machine', alias: 'thigh adductor' },
  { id: 'fb_wadenheben_stehend', name: 'Wadenheben stehend', prim: ['calves'], sec: [], equip: 'machine', alias: 'standing calf raises' },
  { id: 'fb_wadenheben_presse', name: 'Wadenheben an der Beinpresse', prim: ['calves'], sec: [], equip: 'machine', alias: 'calf press on the leg press machine calf press' },
  { id: 'fb_kneeraises', name: 'Hängendes Beinheben', prim: ['abdominals'], sec: [], equip: 'body only', alias: 'hanging leg raise knee hip raise on parallel bars hanging knee raise' },
  { id: 'fb_crunches', name: 'Crunches', prim: ['abdominals'], sec: [], equip: 'body only', alias: 'crunches' },
  { id: 'fb_kabelcrunch', name: 'Kabel-Crunch', prim: ['abdominals'], sec: [], equip: 'cable', alias: 'cable crunch' },
  { id: 'fb_plank', name: 'Plank (Unterarmstütz)', prim: ['abdominals'], sec: ['lower back'], equip: 'body only', alias: 'plank' },
  { id: 'fb_nacken', name: 'Nackenheben', prim: ['neck'], sec: [], equip: 'other', alias: 'neck flexion' }
];
