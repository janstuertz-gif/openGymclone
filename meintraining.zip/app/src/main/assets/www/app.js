'use strict';

const APP = $('#app'), NAV = $('#nav');
let AWAKE = null;
let EDITFROM = '';   // Seite, von der aus der Plan-Editor geoeffnet wurde

/* ================= Navigation ================= */
const go = h => { if (location.hash === h) render(); else location.hash = h; };
const routeParts = () => (location.hash || '#/').replace(/^#\/?/, '').split('/').filter(Boolean);

function render() {
  const p = routeParts(), top = p[0] || 'home';
  let html;
  switch (top) {
    case 'lib': html = viewLib(); break;
    case 'hist': html = p[1] ? viewHistItem(p[1]) : viewHist(); break;
    case 'plan': html = viewPlan(p[1]); break;
    case 'day': html = viewDay(p[1]); break;
    case 'w': html = viewWorkout(); break;
    case 'settings': html = viewSettings(); break;
    default: html = viewHome();
  }
  const y = window.scrollY, same = LASTH === location.hash;
  APP.innerHTML = html;
  LASTH = location.hash;
  window.scrollTo(0, same ? y : 0);
  const hideNav = top === 'w' || top === 'plan' || top === 'day' || top === 'settings' || (top === 'lib' && PICK) || (top === 'hist' && p[1]);
  NAV.innerHTML = navHtml(top === 'plan' || top === 'day' || top === 'settings' || top === 'w' ? 'home' : top);
  NAV.style.display = hideNav ? 'none' : '';
  document.body.classList.toggle('inw', top === 'w');
  const awake = top === 'w';
  if (AWAKE !== awake) { AWAKE = awake; bridge('keepAwake', awake); }
  drawOv();
}
function drawOv() {
  const el = $('#ov');
  if (!el) return;
  const html = OV ? ovHtml() : '';
  if (!html) { OV = null; el.innerHTML = ''; el.className = ''; return; }
  el.innerHTML = html;
  el.className = 'on';
}
function closeOv() {
  const wasQr = OV && OV.type === 'qr';
  OV = null; drawOv();
  if (wasQr) bridge('brightness', false);
}
function goBack() {
  const p = routeParts(), top = p[0] || 'home';
  if (top === 'hist' && p[1]) { go('#/hist'); return; }
  if (top === 'plan' && EDITFROM) { const h = EDITFROM; EDITFROM = ''; go(h); return; }
  go('#/');
}

/* ================= Training ================= */
async function startWorkout(rid) {
  const r = S.routines.find(x => x.id === rid);
  if (!r) return;
  if (!r.ex.length) { toast('Dieser Plan hat noch keine Übungen.'); return; }
  if (S.current) {
    if (S.current.rid === rid) { go('#/w'); return; }
    const ok = await dlg({ title: 'Laufendes Training ersetzen?', text: S.current.name + ' ist noch nicht beendet und wird verworfen.', ok: 'Neu starten', danger: true });
    if (!ok) return;
  }
  S.current = {
    id: uid(), rid: r.id, name: r.name, start: Date.now(),
    items: r.ex.map(e => ({
      key: e.key || e.dbId || e.name, name: e.name, dbId: e.dbId, rest: e.rest || 90, note: e.note || '',
      sets: e.sets.map(s => ({ pw: s.w, pr: s.r, w: s.w != null ? fmt(s.w) : '', r: '', done: false }))
    }))
  };
  save(); go('#/w');
}
function applyWeights(c) {
  const r = S.routines.find(x => x.id === c.rid);
  if (!r) return;
  c.items.forEach(it => {
    const e = r.ex.find(x => (x.key || x.dbId || x.name) === it.key);
    if (!e) return;
    it.sets.forEach((s, j) => { const w = num(s.w); if (s.done && w != null && e.sets[j]) e.sets[j].w = w; });
  });
}
const mkSets = () => Array.from({ length: 3 }, () => ({ w: null, r: '8-12' }));
function applyPick(p, it) {
  const r = p.id ? S.routines.find(x => x.id === p.id) : null;
  if (p.mode === 'padd' && r) {
    r.ex.push({ id: uid(), key: it.id, name: it.name, dbId: it.id, q: [], manual: true, rest: S.settings.rest || 90, note: '', sets: mkSets() });
  } else if (p.mode === 'plreplace' && r && r.ex[p.i]) {
    const e = r.ex[p.i]; e.key = it.id; e.name = it.name; e.dbId = it.id; e.q = []; e.manual = true;
  } else if (p.mode === 'pllink' && r && r.ex[p.i]) {
    r.ex[p.i].dbId = it.id; r.ex[p.i].manual = true;
  } else if (p.mode === 'wadd' && S.current) {
    S.current.items.push({
      key: it.id, name: it.name, dbId: it.id, rest: S.settings.rest || 90, note: '',
      sets: Array.from({ length: 3 }, () => ({ pw: null, pr: '8-12', w: '', r: '', done: false }))
    });
  } else if (p.mode === 'wreplace' && S.current && S.current.items[p.i]) {
    const x = S.current.items[p.i]; x.key = it.id; x.name = it.name; x.dbId = it.id;
  } else if (p.mode === 'wlink' && S.current && S.current.items[p.i]) {
    S.current.items[p.i].dbId = it.id;
  }
}
const planOf = id => S.routines.find(r => r.id === id);
const swap = (arr, a, b) => { if (a < 0 || b < 0 || a >= arr.length || b >= arr.length) return false; const t = arr[a]; arr[a] = arr[b]; arr[b] = t; return true; };

/* ================= Aktionen (per data-a) ================= */
let REM_WANT = false;
let LAUNCH_NAV = 0;

const A = {
  nav: t => { PICK = null; go(t.dataset.to === 'home' ? '#/' : '#/' + t.dataset.to); },
  back: () => goBack(),
  settings: () => go('#/settings'),
  start: t => startWorkout(t.dataset.id),
  resume: () => go('#/w'),
  day: t => go('#/day/' + t.dataset.id),
  edit: t => { EDITFROM = (routeParts()[0] === 'day') ? location.hash : ''; go('#/plan/' + t.dataset.id); },
  seted: async t => {
    const r = planOf(t.dataset.id), e = r && r.ex[+t.dataset.i], j = +t.dataset.s;
    if (!e || !e.sets[j]) return;
    const isW = t.dataset.f === 'w', s = e.sets[j];
    const res = await dlg({
      title: e.name, text: 'Satz ' + (j + 1) + (isW ? ': Gewicht in kg' : ': Wiederholungen'),
      input: isW ? fmt(s.w) : String(s.r == null ? '' : s.r), ph: isW ? 'kg' : '8-12', im: isW ? 'decimal' : 'text',
      check: e.sets.length > 1 ? (isW ? 'Gewicht für alle Sätze übernehmen' : 'Wiederholungen für alle Sätze übernehmen') : null,
      ok: 'Speichern'
    });
    if (!res) return;
    const val = isW ? num(res.value) : String(res.value).trim();
    if (!isW && !val) { toast('Wiederholungen dürfen nicht leer sein'); return; }
    (res.checked ? e.sets : [s]).forEach(x => { if (isW) x.w = val; else x.r = val; });
    save(); render();
  },
  newplan: () => { const r = { id: uid(), name: 'Neuer Plan', day: null, sub: '', ex: [] }; S.routines.push(r); save(); go('#/plan/' + r.id); },

  /* --- QR --- */
  qrscan: () => { if (window.Android) bridge('scanQr'); else A.qrmanual(); },
  qrmanual: async () => {
    const res = await dlg({ title: 'QR-Inhalt eingeben', text: 'Falls das Scannen nicht klappt: den Text des QR-Codes hier einfügen.', input: QR, ph: 'Inhalt des QR-Codes', ok: 'Speichern' });
    if (res && res.value.trim()) window.onQr(res.value.trim());
  },
  qrdel: async () => {
    const ok = await dlg({ title: 'QR-Code löschen?', text: 'Er verschwindet aus der App und vom Widget.', ok: 'Löschen', danger: true });
    if (ok) { QR = ''; bridge('setQr', ''); render(); }
  },
  remtest: () => {
    if (!window.Android) { toast('Die Test-Benachrichtigung gibt es nur in der App'); return; }
    const r = sortedRoutines().find(x => x.day === new Date().getDay()) || sortedRoutines().find(x => x.day != null) || S.routines[0];
    if (!r) { toast('Lege zuerst einen Plan an'); return; }
    bridge('testReminder', r.id, r.name, shortList(r));
  },
  qrfull: () => { if (!QR) return; OV = { type: 'qr' }; drawOv(); bridge('brightness', true); },
  qrclose: () => closeOv(),

  /* --- Training --- */
  tick: t => {
    const i = +t.dataset.i, j = +t.dataset.s, c = S.current;
    if (!c) return;
    const it = c.items[i], st = it.sets[j];
    if (!st.done) {
      const last = lastFor(it.key), l = last && last[j];
      if (st.w === '' && l && l.w != null) st.w = fmt(l.w);
      if (st.r === '') { if (l && l.r) st.r = String(l.r); else if (/^\d+$/.test(st.pr)) st.r = st.pr; }
      st.done = true;
      startRest(it.rest || 90);
    } else { st.done = false; }
    save(); render();
  },
  addset: t => {
    const it = S.current && S.current.items[+t.dataset.i]; if (!it) return;
    const l = it.sets[it.sets.length - 1];
    it.sets.push({ pw: l ? l.pw : null, pr: l ? l.pr : '8-12', w: l && l.pw != null ? fmt(l.pw) : '', r: '', done: false });
    save(); render();
  },
  delset: async t => {
    const it = S.current && S.current.items[+t.dataset.i]; if (!it || it.sets.length <= 1) return;
    const l = it.sets[it.sets.length - 1];
    if (l.done) { const ok = await dlg({ title: 'Letzten Satz löschen?', text: 'Er ist schon abgehakt.', ok: 'Löschen', danger: true }); if (!ok) return; }
    it.sets.pop(); save(); render();
  },
  finish: async () => {
    const c = S.current; if (!c) return;
    const n = doneCount(c);
    const res = await dlg(n
      ? { title: 'Training beenden?', text: n + ' Sätze erledigt.', ok: 'Speichern', check: 'Gewichte in den Plan übernehmen' }
      : { title: 'Training verwerfen?', text: 'Es wurde noch kein Satz abgehakt.', ok: 'Verwerfen', danger: true });
    if (!res) return;
    if (n) {
      S.workouts.unshift({
        id: c.id, rid: c.rid, name: c.name, start: c.start, end: Date.now(),
        items: c.items.map(it => ({ key: it.key, name: it.name, dbId: it.dbId, sets: it.sets.map(s => ({ w: num(s.w), r: s.r, done: s.done })) }))
      });
      if (res.checked) applyWeights(c);
    }
    S.current = null; REST.end = 0; drawRest(); save();
    go('#/'); toast(n ? 'Training gespeichert' : 'Training verworfen');
  },
  wadd: () => { PICK = { mode: 'wadd', back: '#/w' }; go('#/lib'); },
  wreplace: t => { PICK = { mode: 'wreplace', i: +t.dataset.i, back: '#/w' }; OV = null; go('#/lib'); },
  wlink: t => { PICK = { mode: 'wlink', i: +t.dataset.i, back: '#/w' }; OV = null; go('#/lib'); },
  wremove: async t => {
    const ok = await dlg({ title: 'Übung entfernen?', text: 'Nur aus diesem Training, dein Plan bleibt unverändert.', ok: 'Entfernen', danger: true });
    if (!ok || !S.current) return;
    S.current.items.splice(+t.dataset.i, 1); OV = null; save(); render();
  },
  rminus: () => { if (REST.end) { REST.end -= 15000; REST.total = Math.max(REST.total, 15); tickRest(); } },
  rplus: () => { if (REST.end) { REST.end += 15000; REST.total += 15; REST.fin = false; tickRest(); } },
  rskip: () => { REST.end = 0; drawRest(); },

  /* --- Overlays --- */
  exinfo: t => { OV = { type: 'ex', ctx: t.dataset.ctx, i: +t.dataset.i, id: t.dataset.id }; drawOv(); },
  ovclose: () => closeOv(),
  video: t => {
    const url = 'https://www.youtube.com/results?search_query=' + encodeURIComponent(t.dataset.q);
    if (window.Android) bridge('openUrl', url); else window.open(url, '_blank');
  },

  /* --- Uebungen --- */
  libm: t => { LIBQ.m = t.dataset.m; LIBQ.n = 60; render(); },
  libmore: () => { LIBQ.n += 60; $('#liblist').innerHTML = libList(); },
  libopen: t => { OV = { type: 'ex', ctx: 'lib', id: t.dataset.id }; drawOv(); },
  libadd: t => { OV = { type: 'addto', id: t.dataset.id }; drawOv(); },
  addto: t => {
    const r = planOf(t.dataset.id), it = getItem(t.dataset.x); if (!r || !it) return;
    applyPick({ mode: 'padd', id: r.id }, it); save(); OV = null; drawOv();
    toast(it.name + ' zu ' + r.name + ' hinzugefügt');
  },
  pickcancel: () => { const b = PICK && PICK.back; PICK = null; OV = null; go(b || '#/'); },
  pickchoose: t => {
    const it = getItem(t.dataset.id), p = PICK; if (!it || !p) return;
    applyPick(p, it); PICK = null; OV = null; save(); go(p.back || '#/');
    toast(it.name + ' übernommen');
  },
  newcustom: () => { OV = { type: 'newex' }; drawOv(); },
  nxsave: () => {
    const name = ($('#nxname').value || '').trim();
    if (!name) { toast('Bitte einen Namen eingeben'); return; }
    S.custom.push({ id: 'c_' + uid(), name, prim: [$('#nxm').value], equip: $('#nxe').value });
    save(); OV = null; LIBQ.q = ''; LIBQ.m = ''; render(); toast('Eigene Übung gespeichert');
  },
  customdel: async t => {
    const ok = await dlg({ title: 'Eigene Übung löschen?', ok: 'Löschen', danger: true });
    if (!ok) return;
    S.custom = S.custom.filter(c => c.id !== t.dataset.id); OV = null; save(); render();
  },

  /* --- Plan bearbeiten --- */
  pladd: t => { PICK = { mode: 'padd', id: t.dataset.id, back: '#/plan/' + t.dataset.id }; go('#/lib'); },
  plreplace: t => { PICK = { mode: 'plreplace', id: t.dataset.id, i: +t.dataset.i, back: location.hash }; OV = null; go('#/lib'); },
  pllink: t => { PICK = { mode: 'pllink', id: t.dataset.id, i: +t.dataset.i, back: location.hash }; OV = null; go('#/lib'); },
  plremove: async t => {
    const ok = await dlg({ title: 'Übung aus dem Plan entfernen?', ok: 'Entfernen', danger: true });
    if (!ok) return;
    const r = planOf(t.dataset.id); if (r) r.ex.splice(+t.dataset.i, 1); OV = null; save(); render();
  },
  exup: t => { const r = planOf(t.dataset.id), i = +t.dataset.i; if (r && swap(r.ex, i, i - 1)) { save(); render(); } },
  exdown: t => { const r = planOf(t.dataset.id), i = +t.dataset.i; if (r && swap(r.ex, i, i + 1)) { save(); render(); } },
  pladdset: t => {
    const r = planOf(t.dataset.id), e = r && r.ex[+t.dataset.i]; if (!e) return;
    const l = e.sets[e.sets.length - 1];
    e.sets.push({ w: l ? l.w : null, r: l ? l.r : '8-12' }); save(); render();
  },
  delplset: t => {
    const r = planOf(t.dataset.id), e = r && r.ex[+t.dataset.i]; if (!e) return;
    if (e.sets.length <= 1) { toast('Mindestens ein Satz'); return; }
    e.sets.splice(+t.dataset.s, 1); save(); render();
  },
  plsame: t => {
    const r = planOf(t.dataset.id), e = r && r.ex[+t.dataset.i]; if (!e || !e.sets.length) return;
    const f = e.sets[0]; e.sets.forEach(s => { s.w = f.w; s.r = f.r; }); save(); render();
  },
  plandel: async t => {
    const r = planOf(t.dataset.id); if (!r) return;
    const ok = await dlg({ title: r.name + ' löschen?', text: 'Der Plan wird entfernt. Dein Verlauf bleibt erhalten.', ok: 'Löschen', danger: true });
    if (!ok) return;
    S.routines = S.routines.filter(x => x.id !== r.id); EDITFROM = ''; save(); go('#/');
  },
  setday: t => { const r = planOf(t.dataset.id); if (!r) return; r.day = t.dataset.d === '' ? null : +t.dataset.d; save(); render(); },

  /* --- Verlauf --- */
  histopen: t => go('#/hist/' + t.dataset.id),
  histdel: async t => {
    const ok = await dlg({ title: 'Training löschen?', text: 'Es verschwindet aus dem Verlauf.', ok: 'Löschen', danger: true });
    if (!ok) return;
    S.workouts = S.workouts.filter(w => w.id !== t.dataset.id); save(); go('#/hist');
  },

  /* --- Einstellungen --- */
  export: () => {
    if (!window.Android) { toast('Backup geht nur in der App'); return; }
    const d = new Date();
    bridge('exportBackup', JSON.stringify({ app: 'meintraining', v: 1, state: S, qr: QR }), 'meintraining-backup-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '.json');
  },
  import: () => { if (!window.Android) { toast('Backup geht nur in der App'); return; } bridge('importBackup'); },
  addpreset: () => { PRESET.forEach(p => S.routines.push(cloneRoutine(p))); autoLink(); save(); toast('Plan hinzugefügt'); render(); },
  reset: async () => {
    const ok = await dlg({ title: 'Alles zurücksetzen?', text: 'Pläne, Verlauf und QR-Code werden gelöscht. Das lässt sich nicht rückgängig machen.', ok: 'Zurücksetzen', danger: true });
    if (!ok) return;
    S = freshState(); QR = ''; bridge('setQr', ''); autoLink(); save(); go('#/');
  },

  /* --- Dialog --- */
  dlgok: () => closeDlg(true),
  dlgno: () => closeDlg(false)
};

/* ================= Ereignisse ================= */
document.addEventListener('click', e => {
  const t = e.target.closest ? e.target.closest('[data-a]') : null;
  if (!t) return;
  const f = A[t.dataset.a];
  if (f) { e.preventDefault(); f(t, e); }
});

document.addEventListener('input', e => {
  const t = e.target, f = t.dataset && t.dataset.f;
  if (!f) return;
  const i = +t.dataset.i, s = +t.dataset.s;
  const r = t.dataset.id ? planOf(t.dataset.id) : null;
  switch (f) {
    case 'w': if (S.current) S.current.items[i].sets[s].w = t.value; break;
    case 'r': if (S.current) S.current.items[i].sets[s].r = t.value; break;
    case 'rname': if (r) r.name = t.value; break;
    case 'rsub': if (r) r.sub = t.value; break;
    case 'pw': if (r) r.ex[i].sets[s].w = num(t.value); break;
    case 'pr': if (r) r.ex[i].sets[s].r = t.value; break;
    case 'prest': if (r) r.ex[i].rest = parseInt(t.value, 10) || 90; break;
    case 'pnote': if (r) r.ex[i].note = t.value; break;
    case 'defrest': S.settings.rest = parseInt(t.value, 10) || 90; break;
    case 'qrhome': S.settings.qrHome = !!t.checked; break;
    case 'remon':
      if (t.checked) {
        REM_WANT = true;
        if (window.Android) bridge('requestNotifPermission'); else window.onNotifPerm(true);
      } else { S.settings.remOn = false; save(); render(); }
      return;
    case 'remtime': S.settings.remTime = t.value || '17:00'; break;
    case 'lq': LIBQ.q = t.value; LIBQ.n = 60; { const l = $('#liblist'); if (l) l.innerHTML = libList(); } return;
  }
  save();
});

/* Enter im Eingabedialog = Speichern */
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && DLG && e.target && e.target.id === 'dlgin') { e.preventDefault(); closeDlg(true); }
});

/* Tastatur offen (Fensterhoehe schrumpft): Pausen-Leiste und Navigation ausblenden, damit nichts verdeckt wird */
let KW = window.innerWidth, KH = window.innerHeight;
function checkKb() {
  if (window.innerWidth !== KW) { KW = window.innerWidth; KH = window.innerHeight; }
  KH = Math.max(KH, window.innerHeight);
  document.body.classList.toggle('kb', window.innerHeight < KH * 0.75);
}
window.addEventListener('resize', checkKb);

/* Nach laengerer Pause (App im Hintergrund) wieder auf der Startseite landen, dort liegt der QR-Code.
   Ein laufendes Training bleibt offen. */
let HIDDEN_AT = 0;
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { HIDDEN_AT = Date.now(); return; }
  if (Date.now() - LAUNCH_NAV < 4000) { HIDDEN_AT = 0; return; }
  const top = routeParts()[0] || 'home';
  if (HIDDEN_AT && Date.now() - HIDDEN_AT > 10 * 60 * 1000 && top !== 'w') {
    if (DLG) closeDlg(false);
    PICK = null; OV = null; go('#/');
  }
  HIDDEN_AT = 0;
});

/* ================= Rueckmeldungen von Android ================= */
window.onQr = text => {
  QR = text; bridge('setQr', text);
  toast('QR-Code gespeichert'); render();
};
window.onQrError = msg => toast('Scanner: ' + msg);
window.checkLaunch = () => {
  const day = bridge('consumeOpenDay');
  if (day && S.routines.some(r => r.id === day)) { LAUNCH_NAV = Date.now(); OV = null; PICK = null; go('#/day/' + day); }
  if (bridge('consumeOpenQr') === true) {
    LAUNCH_NAV = Date.now();
    if (QR) { OV = { type: 'qr' }; drawOv(); bridge('brightness', true); } else go('#/');
  }
};
window.onNotifPerm = granted => {
  if (!REM_WANT) return;
  REM_WANT = false;
  S.settings.remOn = !!granted;
  save(); syncReminder(true); render();
  if (!granted) toast('Benachrichtigungen sind für die App ausgeschaltet. Bitte in den Android-Einstellungen erlauben.');
};
window.onImport = async text => {
  let d;
  try { d = JSON.parse(text); } catch (e) { toast('Die Datei ist kein gültiges Backup'); return; }
  if (!d || d.app !== 'meintraining' || !d.state || !Array.isArray(d.state.routines)) { toast('Die Datei ist kein Backup dieser App'); return; }
  const ok = await dlg({ title: 'Backup laden?', text: 'Aktuelle Pläne und Verlauf werden ersetzt.', ok: 'Laden', danger: true });
  if (!ok) return;
  S = d.state; S.custom = S.custom || []; S.workouts = S.workouts || []; S.settings = S.settings || { rest: 90 };
  migrateDays();
  if (typeof d.qr === 'string') { QR = d.qr; bridge('setQr', QR); }
  autoLink(); save(); go('#/'); toast('Backup geladen');
};
window.onBack = () => {
  if (DLG) { closeDlg(false); return true; }
  if (OV) { closeOv(); return true; }
  if (PICK) { A.pickcancel(); return true; }
  const top = routeParts()[0] || 'home';
  if (top === 'home') return false;
  goBack(); return true;
};

/* ================= Start ================= */
async function init() {
  S = loadState() || freshState();
  S.settings = S.settings || { rest: 90 }; S.custom = S.custom || []; S.workouts = S.workouts || [];
  migrateDays();
  QR = String(bridge('getQr') || '');
  save();
  render();
  window.addEventListener('hashchange', render);
  setInterval(() => {
    tickRest();
    const w = $('#wtime');
    if (w && S.current) w.textContent = clock((Date.now() - S.current.start) / 1000);
  }, 500);
  await loadDB();
  autoLink();
  render();
  checkLaunch();
  syncReminder(true);
  setTimeout(prefetchPlan, 1500);
}
init();
