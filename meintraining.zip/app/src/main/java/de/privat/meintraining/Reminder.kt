package de.privat.meintraining

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.util.Calendar

/**
 * Erinnerung am Trainingstag. Die Web-Oberflaeche schickt Uhrzeit und Plan pro Wochentag als JSON,
 * hier wird gespeichert und der naechste Wecker gesetzt.
 */
object Reminder {
    const val ACTION_OPEN_DAY = "de.privat.meintraining.OPEN_DAY"
    private const val CHANNEL = "training"
    private const val PREFS = "reminder"
    private const val KEY = "cfg"

    fun save(ctx: Context, json: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply()
        schedule(ctx)
    }

    private fun config(ctx: Context): JSONObject? {
        return try {
            val s = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            if (s == null) null else JSONObject(s)
        } catch (e: Exception) {
            null
        }
    }

    private fun alarmIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 1, Intent(ctx, ReminderReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** Setzt den naechsten Wecker oder loescht ihn, wenn die Erinnerung aus ist. */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmIntent(ctx))
        val c = config(ctx) ?: return
        if (!c.optBoolean("on", false)) return
        val days = c.optJSONObject("days") ?: return
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        for (i in 0..7) {
            cal.timeInMillis = now
            cal.add(Calendar.DAY_OF_YEAR, i)
            cal.set(Calendar.HOUR_OF_DAY, c.optInt("h", 17))
            cal.set(Calendar.MINUTE, c.optInt("m", 0))
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val day = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 = Sonntag, wie in JavaScript
            if (cal.timeInMillis > now + 1000 && days.has(day.toString())) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, alarmIntent(ctx))
                return
            }
        }
    }

    /** Wird vom Wecker aufgerufen: zeigt die Benachrichtigung fuer den heutigen Plan. */
    fun notifyToday(ctx: Context) {
        val days = config(ctx)?.optJSONObject("days") ?: return
        val day = (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1).toString()
        val d = days.optJSONObject(day) ?: return
        showNotification(ctx, d.optString("id"), d.optString("n"), d.optString("t"))
    }

    fun showNotification(ctx: Context, id: String, name: String, text: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Trainingserinnerung", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val i = Intent(ctx, MainActivity::class.java)
        i.action = ACTION_OPEN_DAY
        i.putExtra("routineId", id)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        val pi = PendingIntent.getActivity(
            ctx, 2, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Heute: $name")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(1001, n)
        } catch (e: SecurityException) {
        }
    }
}
