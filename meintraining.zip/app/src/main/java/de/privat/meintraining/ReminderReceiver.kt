package de.privat.meintraining

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Wird vom Wecker ausgeloest: Benachrichtigung zeigen und den naechsten Wecker setzen. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminder.notifyToday(context)
        Reminder.schedule(context)
    }
}

/** Nach Neustart des Handys oder nach einem App-Update die Erinnerung wieder einplanen. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminder.schedule(context)
    }
}
