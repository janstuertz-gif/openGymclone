package de.privat.meintraining

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

/** Homescreen-Widget: zeigt den gespeicherten Gym-QR-Code. Tippen oeffnet ihn gross in der App. */
class QrWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, build(context))
        }
    }

    companion object {
        fun refreshAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, QrWidgetProvider::class.java))
            for (id in ids) {
                mgr.updateAppWidget(id, build(context))
            }
        }

        private fun build(context: Context): RemoteViews {
            val v = RemoteViews(context.packageName, R.layout.widget_qr)
            val text = QrStore.get(context)
            val bmp = if (text.isNullOrEmpty()) null else QrStore.bitmap(text, 600)
            if (bmp != null) {
                v.setImageViewBitmap(R.id.qr, bmp)
                v.setViewVisibility(R.id.qr, View.VISIBLE)
                v.setViewVisibility(R.id.empty, View.GONE)
            } else {
                v.setViewVisibility(R.id.qr, View.GONE)
                v.setViewVisibility(R.id.empty, View.VISIBLE)
            }
            val i = Intent(context, MainActivity::class.java)
            i.action = "de.privat.meintraining.OPEN_QR"
            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            val pi = PendingIntent.getActivity(
                context, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.root, pi)
            return v
        }
    }
}
