package de.privat.meintraining

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var pendingExport: String? = null

    @Volatile
    private var openQr = false

    private val createDoc = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        val data = pendingExport
        pendingExport = null
        if (uri != null && data != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(data.toByteArray(Charsets.UTF_8))
                }
                toast("Backup gespeichert")
            } catch (e: Exception) {
                toast("Fehler: " + e.message)
            }
        }
    }

    private val openDoc = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.use { input ->
                    input.readBytes().toString(Charsets.UTF_8)
                } ?: ""
                js("window.onImport && window.onImport(" + JSONObject.quote(text) + ")")
            } catch (e: Exception) {
                toast("Fehler: " + e.message)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openQr = isOpenQrIntent(intent)

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#10151B"))
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mediaPlaybackRequiresUserGesture = false
        // Bilder aus dem Netz bleiben im Cache und sind danach auch offline da.
        s.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
        WebView.setWebContentsDebuggingEnabled(true)

        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (e: Exception) {
                }
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.onBack ? window.onBack() : false)") { r ->
                    if (r != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (isOpenQrIntent(intent)) {
            openQr = true
            js("window.checkLaunch && window.checkLaunch()")
        }
    }

    private fun isOpenQrIntent(i: Intent?): Boolean =
        i?.action == "de.privat.meintraining.OPEN_QR"

    private fun js(code: String) {
        web.post { web.evaluateJavascript(code, null) }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    @Suppress("DEPRECATION")
    private fun vibrator(): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

    private fun startScan() {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .build()
        GmsBarcodeScanning.getClient(this, options).startScan()
            .addOnSuccessListener { barcode ->
                val raw = barcode.rawValue ?: ""
                if (raw.isEmpty()) {
                    js("window.onQrError && window.onQrError('Leerer Code')")
                } else {
                    js("window.onQr && window.onQr(" + JSONObject.quote(raw) + ")")
                }
            }
            .addOnCanceledListener { }
            .addOnFailureListener { e ->
                val msg = e.message ?: "Scanner nicht verfügbar"
                js("window.onQrError && window.onQrError(" + JSONObject.quote(msg) + ")")
            }
    }

    /** Wird aus der Web-Oberfläche als "Android.<name>(...)" aufgerufen. */
    inner class Bridge {

        @JavascriptInterface
        fun getQr(): String = QrStore.get(this@MainActivity) ?: ""

        @JavascriptInterface
        fun setQr(text: String) {
            QrStore.set(this@MainActivity, text)
            QrWidgetProvider.refreshAll(this@MainActivity)
        }

        @JavascriptInterface
        fun qrMatrix(text: String): String = QrStore.matrix(text)

        @JavascriptInterface
        fun scanQr() {
            runOnUiThread { startScan() }
        }

        @JavascriptInterface
        fun consumeOpenQr(): Boolean {
            val v = openQr
            openQr = false
            return v
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: Exception) {
                    toast("Link konnte nicht geöffnet werden")
                }
            }
        }

        @JavascriptInterface
        fun brightness(max: Boolean) {
            runOnUiThread {
                val lp = window.attributes
                lp.screenBrightness =
                    if (max) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                window.attributes = lp
            }
        }

        @JavascriptInterface
        fun keepAwake(on: Boolean) {
            runOnUiThread {
                if (on) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }
        }

        @JavascriptInterface
        fun vibrate(ms: Int) {
            try {
                vibrator()?.vibrate(
                    VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun exportBackup(json: String, name: String) {
            runOnUiThread {
                pendingExport = json
                createDoc.launch(name)
            }
        }

        @JavascriptInterface
        fun importBackup() {
            runOnUiThread { openDoc.launch(arrayOf("application/json", "text/plain", "*/*")) }
        }

        @JavascriptInterface
        fun showToast(msg: String) {
            runOnUiThread { toast(msg) }
        }
    }
}
