package de.privat.meintraining

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.common.BitMatrix
import com.google.zxing.qrcode.QRCodeWriter

/** Speichert den Gym-QR-Code (Text) und erzeugt daraus Matrix bzw. Bitmap. */
object QrStore {
    private const val PREFS = "qr"
    private const val KEY = "text"

    fun get(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)

    fun set(ctx: Context, text: String?) {
        val e = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (text.isNullOrEmpty()) e.remove(KEY) else e.putString(KEY, text)
        e.apply()
    }

    private fun encode(text: String): BitMatrix? {
        return try {
            val hints = HashMap<EncodeHintType, Any>()
            hints[EncodeHintType.MARGIN] = 0
            if (text.any { it.code > 0xFF }) {
                hints[EncodeHintType.CHARACTER_SET] = "UTF-8"
            }
            QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints)
        } catch (e: Exception) {
            null
        }
    }

    /** Liefert "<Kantenlaenge>:<Bits>" (1 = dunkles Modul) oder "" bei Fehler. */
    fun matrix(text: String): String {
        val m = encode(text) ?: return ""
        val n = m.width
        val sb = StringBuilder(n * n + 8)
        sb.append(n).append(':')
        for (y in 0 until n) {
            for (x in 0 until n) {
                sb.append(if (m.get(x, y)) '1' else '0')
            }
        }
        return sb.toString()
    }

    /** Weisses Bitmap mit QR-Code und 4 Modulen Rand, fuer das Widget. */
    fun bitmap(text: String, size: Int): Bitmap? {
        val m = encode(text) ?: return null
        val n = m.width
        val quiet = 4
        val px = maxOf(1, size / (n + 2 * quiet))
        val dim = px * (n + 2 * quiet)
        val pixels = IntArray(dim * dim) { Color.WHITE }
        for (y in 0 until n) {
            for (x in 0 until n) {
                if (m.get(x, y)) {
                    val x0 = (x + quiet) * px
                    val y0 = (y + quiet) * px
                    for (dy in 0 until px) {
                        val row = (y0 + dy) * dim
                        for (dx in 0 until px) {
                            pixels[row + x0 + dx] = Color.BLACK
                        }
                    }
                }
            }
        }
        val bmp = Bitmap.createBitmap(dim, dim, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, dim, 0, 0, dim, dim)
        return bmp
    }
}
