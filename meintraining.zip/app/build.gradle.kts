plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.privat.meintraining"
    compileSdk = 34

    defaultConfig {
        applicationId = "de.privat.meintraining"
        minSdk = 26
        targetSdk = 34
        // versionCode steigt mit der Uhrzeit, so lassen sich neue Builds immer ueber alte installieren
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    // Fester Schluessel: jede neue Version laesst sich ueber die alte installieren,
    // ohne dass Trainingsdaten verloren gehen.
    signingConfigs {
        create("fixed") {
            storeFile = file("meintraining.keystore")
            storePassword = "meintraining"
            keyAlias = "meintraining"
            keyPassword = "meintraining"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("fixed")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("com.google.zxing:core:3.5.3")
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
}
